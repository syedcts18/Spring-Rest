package com.tbp.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudJdbcTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
